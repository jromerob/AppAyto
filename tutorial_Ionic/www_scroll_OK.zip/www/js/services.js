

angular.module('starter.services', [])
        .service('imageService', function ($http,$q) {
            /**
             * 
             * @param {type} id
             * @returns {String}
             */
            this.getLargeURL = function (id) {
                if (id>0) {
                    return ($http.get(configHelper.getImagesURL() + "/" + id, {ignoreLoadingBar: true})
                            .then(
                                    function successCallback(response) {
                                        var dataImage=response.data.media_details.sizes;
                                        return dataImage["large"].source_url
                                    },
                                    function errorCallback(response) {
                                        if (!angular.isObject(response.data) || !response.data.message) {
                                            return("Error desconocido.");
                                        }
                                        return(response.data.message);
                                    }
                            )
                    );
                } else {
                     return "";
                }
            };
            /**
             * 
             * @param {type} id
             * @returns {String}
             */
            this.getThumbnailURL = function (id) {
                
                if (id>0) {
                    return ($http.get(configHelper.getImagesURL() + "/" + id, {ignoreLoadingBar: true})
                            .then(
                                    function successCallback(response) {
                                        var dataImage=response.data.media_details.sizes;
                                        return dataImage["thumbnail"].source_url
                                    },
                                    function errorCallback(response) {
                                        if (!angular.isObject(response.data) || !response.data.message) {
                                            return("An unknown error occurred.");
                                        }
                                        return(response.data.message);
                                    }
                            )
                    );
                } else {
                     return "";
                }
            };
            /**
             * Recibe un array de posts de wp y rellena cada post con la url de su featured image
             */
            this.populateImagePosts = function (arrayPosts) {
                
                var defered = $q.defer();
                var promise = defered.promise;
                var arrayPromesas=[]; 
                var claveMediaJson=configHelper.getJsonMediaKey();

                
                arrayPosts.forEach(function(post){
                    //añadimos las promesas al array para despues verificar su finalizacion
                    if (post[claveMediaJson]>1){
                        var promesa=$http.get(configHelper.getImagesURL() + "/" + post[claveMediaJson], {ignoreLoadingBar: true})
                                        .then(function(response){
                                            //asignamos los diferentes tamaños si existen
                                            post.url_featured_media_thumbnail=(response.data.media_details.sizes.hasOwnProperty('thumbnail')? response.data.media_details.sizes["thumbnail"].source_url:"");
                                            post.url_featured_media_medium=(response.data.media_details.sizes.hasOwnProperty('medium')? response.data.media_details.sizes["medium"].source_url:"");
                                            post.url_featured_media_large=(response.data.media_details.sizes.hasOwnProperty('large')? response.data.media_details.sizes["large"].source_url:"");
                                        });
                        arrayPromesas.push(promesa);
                    } else {
                        post.url_featured_media="";
                    }
                    
                });
                
                //cuando todas las promesas han finalizado, resolvemos la promesa de la funcion
                $q.all(arrayPromesas).then(
                        function successCallback(response) {
                            defered.resolve(response);
                        },
                        function errorCallback(response) {
                            defered.reject(response.data.message)
                        }
                );
        
                return promise;
            }
        })
.service('postService', function ($http,$q,configHelper) {
           /**
            * Obtiene la página de posts correspondiente al parametro recibido
            * @param {type} page
            * @returns {defered.promise}
            */
            this.getPosts = function (page) {
                var defered = $q.defer();
                var promise = defered.promise;
                page=(page == undefined)? 1 : page;
                
                
                $http({
                method: 'GET',
                url: configHelper.getPostsURL()+"?page=" + page
                }).then(
                        function successCallback(response) {
                            defered.resolve(response);
                        },
                        function errorCallback(response) {
                            if (response.status==0){
                                defered.reject("No se ha recibido respuesta de " + response.config.url)
                            } else {
                                defered.reject(response.statusText)
                            }
                            
                        }
                    );
                return promise;
            };                
        });